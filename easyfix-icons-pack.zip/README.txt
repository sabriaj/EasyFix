EasyFix Icons Pack

Vendosi këto file në të njëjtin folder ku e ke index.html (root i GitHub Pages):

- favicon.ico
- favicon-32.png
- favicon-16.png
- apple-touch-icon.png

Opsionale (për PWA / manifest):
- icon-192.png
- icon-512.png

Logo për navbar:
- logo-64.png (rekomandohet)
- logo-48.png
